import { Github, Linkedin, Mail, Code2, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";
import { siteConfig } from "@/lib/config";

export function Footer() {

  return (
    <footer className="py-8 px-6 border-t border-border">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <Code2 className="h-5 w-5 text-primary" />
            <span className="font-medium" data-testid="text-footer-name">{siteConfig.name}</span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="ghost"
              asChild
              aria-label="LinkedIn Profile"
              data-testid="link-footer-linkedin"
            >
              <a href={siteConfig.social.linkedin} target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-5 w-5" />
              </a>
            </Button>
            <Button
              size="icon"
              variant="ghost"
              asChild
              aria-label="GitHub Profile"
              data-testid="link-footer-github"
            >
              <a href={siteConfig.social.github} target="_blank" rel="noopener noreferrer">
                <Github className="h-5 w-5" />
              </a>
            </Button>
            <Button
              size="icon"
              variant="ghost"
              asChild
              aria-label="Instagram Profile"
              data-testid="link-footer-instagram"
            >
              <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer">
                <Instagram className="h-5 w-5" />
              </a>
            </Button>
            <Button
              size="icon"
              variant="ghost"
              asChild
              aria-label="Email Contact"
              data-testid="link-footer-email"
            >
              <a href={`mailto:${siteConfig.social.email}`}>
                <Mail className="h-5 w-5" />
              </a>
            </Button>
          </div>

          <p className="text-sm text-muted-foreground" data-testid="text-copyright">
            {siteConfig.currentYear} {siteConfig.name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
