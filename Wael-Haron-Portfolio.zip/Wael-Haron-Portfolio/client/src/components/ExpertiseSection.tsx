import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cloud, Brain, Cog, Database } from "lucide-react";

const expertiseAreas = [
  {
    icon: Cloud,
    title: "Cloud Architecture",
    description: "Designing and implementing scalable cloud solutions using AWS and Google Cloud Platform. Expert in serverless architectures, containerization, and infrastructure as code.",
    tags: ["AWS", "GCP", "Terraform", "CloudFormation"],
  },
  {
    icon: Brain,
    title: "Machine Learning",
    description: "Building and deploying ML models for real-world applications. Experienced with neural networks, NLP, and computer vision using TensorFlow and PyTorch.",
    tags: ["TensorFlow", "PyTorch", "Scikit-learn", "Keras"],
  },
  {
    icon: Cog,
    title: "AI Automation",
    description: "Creating intelligent automation pipelines that reduce manual work and improve efficiency. Specializing in RPA integration with AI-powered decision making.",
    tags: ["MLOps", "CI/CD", "Airflow", "Automation"],
  },
  {
    icon: Database,
    title: "Data Engineering",
    description: "Building robust data pipelines and analytics platforms. Expertise in ETL processes, data warehousing, and real-time data streaming architectures.",
    tags: ["Spark", "Kafka", "BigQuery", "Snowflake"],
  },
];

export function ExpertiseSection() {
  return (
    <section id="expertise" className="py-20 md:py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4" data-testid="badge-section-expertise">Expertise</Badge>
          <h2 className="text-3xl md:text-4xl font-semibold mb-4" data-testid="text-expertise-title">
            What I Bring to the Table
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto" data-testid="text-expertise-subtitle">
            Combining technical depth with practical experience to deliver solutions that matter.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {expertiseAreas.map((area) => (
            <Card
              key={area.title}
              className="p-8 hover-elevate active-elevate-2 transition-all"
              data-testid={`card-expertise-${area.title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <area.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-3">{area.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {area.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {area.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 text-xs font-mono bg-muted rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
