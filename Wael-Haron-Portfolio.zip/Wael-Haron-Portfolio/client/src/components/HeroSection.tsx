import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail, Instagram } from "lucide-react";
import { siteConfig } from "@/lib/config";
import profileImage from "@assets/1760642651281_1765052114239.jpg";

export function HeroSection() {
  const scrollToAbout = () => {
    const element = document.getElementById("about");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden px-6">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-primary/10 dark:from-primary/10 dark:via-background dark:to-primary/5" />
      
      <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 text-center max-w-4xl">
        <div className="mb-8">
          <div className="w-32 h-32 md:w-40 md:h-40 mx-auto rounded-full overflow-hidden border-4 border-primary/20 shadow-xl">
            <img 
              src={profileImage} 
              alt={siteConfig.name}
              className="w-full h-full object-cover object-top"
              data-testid="img-profile"
            />
          </div>
        </div>
        
        <p className="text-sm uppercase tracking-widest text-muted-foreground mb-4" data-testid="text-label">
          {siteConfig.title}
        </p>
        
        <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-foreground via-foreground to-primary bg-clip-text" data-testid="text-hero-name">
          {siteConfig.name}
        </h1>
        
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed" data-testid="text-hero-tagline">
          Passionate about building smart systems that connect{" "}
          <span className="text-foreground font-medium">{siteConfig.hero.highlight1}</span>,{" "}
          <span className="text-foreground font-medium">{siteConfig.hero.highlight2}</span>, and{" "}
          <span className="text-foreground font-medium">{siteConfig.hero.highlight3}</span>.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
          <Button size="lg" onClick={() => scrollToAbout()} data-testid="button-learn-more">
            Learn More
            <ArrowDown className="ml-2 h-4 w-4" />
          </Button>
          
          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="outline"
              asChild
              aria-label="LinkedIn Profile"
              data-testid="link-linkedin"
            >
              <a href={siteConfig.social.linkedin} target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-5 w-5" />
              </a>
            </Button>
            <Button
              size="icon"
              variant="outline"
              asChild
              aria-label="GitHub Profile"
              data-testid="link-github"
            >
              <a href={siteConfig.social.github} target="_blank" rel="noopener noreferrer">
                <Github className="h-5 w-5" />
              </a>
            </Button>
            <Button
              size="icon"
              variant="outline"
              asChild
              aria-label="Instagram Profile"
              data-testid="link-instagram"
            >
              <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer">
                <Instagram className="h-5 w-5" />
              </a>
            </Button>
            <Button
              size="icon"
              variant="outline"
              asChild
              aria-label="Email Contact"
              data-testid="link-email"
            >
              <a href={`mailto:${siteConfig.social.email}`}>
                <Mail className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3">
          <span className="px-4 py-2 rounded-full bg-muted text-sm font-mono" data-testid="badge-python">Python</span>
          <span className="px-4 py-2 rounded-full bg-muted text-sm font-mono" data-testid="badge-tensorflow">TensorFlow</span>
          <span className="px-4 py-2 rounded-full bg-muted text-sm font-mono" data-testid="badge-aws">AWS</span>
          <span className="px-4 py-2 rounded-full bg-muted text-sm font-mono" data-testid="badge-gcp">Google Cloud</span>
        </div>
      </div>

      <button
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-muted-foreground hover:text-foreground transition-colors"
        aria-label="Scroll down"
        data-testid="button-scroll-indicator"
      >
        <ArrowDown className="h-6 w-6" />
      </button>
    </section>
  );
}
