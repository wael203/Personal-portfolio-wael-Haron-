import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Github, Linkedin, Mail, ArrowUpRight, Instagram } from "lucide-react";
import { siteConfig } from "@/lib/config";

const contactLinks = [
  {
    name: "LinkedIn",
    icon: Linkedin,
    href: siteConfig.social.linkedin,
    description: "Connect professionally",
    color: "bg-[#0A66C2]/10 text-[#0A66C2] dark:bg-[#0A66C2]/20",
  },
  {
    name: "GitHub",
    icon: Github,
    href: siteConfig.social.github,
    description: "View my projects",
    color: "bg-foreground/10",
  },
  {
    name: "Instagram",
    icon: Instagram,
    href: siteConfig.social.instagram,
    description: "Follow my journey",
    color: "bg-[#E4405F]/10 text-[#E4405F] dark:bg-[#E4405F]/20",
  },
  {
    name: "Email",
    icon: Mail,
    href: `mailto:${siteConfig.social.email}`,
    description: "Get in touch directly",
    color: "bg-primary/10 text-primary",
  },
];

export function ContactSection() {
  return (
    <section id="contact" className="py-20 md:py-32 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <Badge variant="secondary" className="mb-4" data-testid="badge-section-contact">Contact</Badge>
        <h2 className="text-3xl md:text-4xl font-semibold mb-4" data-testid="text-contact-title">
          Let's Build Something Together
        </h2>
        <p className="text-muted-foreground text-lg mb-12 max-w-2xl mx-auto" data-testid="text-contact-subtitle">
          Open to collaborations, professional connections, and opportunities in AI, cloud computing, and data science.
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {contactLinks.map((link) => (
            <Card
              key={link.name}
              className="p-6 hover-elevate active-elevate-2 transition-all group"
              data-testid={`card-contact-${link.name.toLowerCase()}`}
            >
              <a
                href={link.href}
                target={link.name !== "Email" ? "_blank" : undefined}
                rel={link.name !== "Email" ? "noopener noreferrer" : undefined}
                className="flex flex-col items-center gap-4"
              >
                <div className={`p-4 rounded-full ${link.color}`}>
                  <link.icon className="h-6 w-6" />
                </div>
                <div>
                  <div className="font-semibold flex items-center justify-center gap-1">
                    {link.name}
                    <ArrowUpRight className="h-4 w-4 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                  </div>
                  <p className="text-sm text-muted-foreground">{link.description}</p>
                </div>
              </a>
            </Card>
          ))}
        </div>

        <div className="p-8 rounded-xl bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 border border-primary/10">
          <p className="text-lg mb-6" data-testid="text-cta-message">
            Looking for an experienced AI and Cloud Engineer?
          </p>
          <Button size="lg" asChild data-testid="button-email-cta">
            <a href={`mailto:${siteConfig.social.email}`}>
              <Mail className="mr-2 h-5 w-5" />
              Send me an email
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
