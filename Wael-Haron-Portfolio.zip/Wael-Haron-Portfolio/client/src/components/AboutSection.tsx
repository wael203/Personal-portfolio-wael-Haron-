import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  SiPython, 
  SiTensorflow, 
  SiAmazonwebservices, 
  SiGooglecloud,
  SiDocker,
  SiKubernetes
} from "react-icons/si";

const technologies = [
  { name: "Python", icon: SiPython },
  { name: "TensorFlow", icon: SiTensorflow },
  { name: "AWS", icon: SiAmazonwebservices },
  { name: "Google Cloud", icon: SiGooglecloud },
  { name: "Docker", icon: SiDocker },
  { name: "Kubernetes", icon: SiKubernetes },
];

export function AboutSection() {
  return (
    <section id="about" className="py-20 md:py-32 px-6 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4" data-testid="badge-section-about">About Me</Badge>
          <h2 className="text-3xl md:text-4xl font-semibold" data-testid="text-about-title">
            Building the Future with AI
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-about-description">
              I specialize in creating <span className="text-foreground font-medium">scalable, intelligent applications</span> that 
              leverage the power of modern cloud infrastructure and machine learning. My work focuses on bridging 
              the gap between complex data systems and practical business solutions.
            </p>
            
            <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-about-focus">
              Currently working on <span className="text-foreground font-medium">AI-driven automation projects</span> and 
              continuously learning to push the limits of modern technology. I'm passionate about exploring 
              new frameworks, optimizing algorithms, and building systems that make a real impact.
            </p>

            <div className="pt-4">
              <p className="text-sm uppercase tracking-widest text-muted-foreground mb-3">Current Focus</p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" data-testid="badge-focus-ml">Machine Learning</Badge>
                <Badge variant="outline" data-testid="badge-focus-automation">AI Automation</Badge>
                <Badge variant="outline" data-testid="badge-focus-cloud">Cloud Architecture</Badge>
                <Badge variant="outline" data-testid="badge-focus-data">Data Engineering</Badge>
              </div>
            </div>
          </div>

          <div>
            <Card className="p-8">
              <h3 className="text-lg font-semibold mb-6" data-testid="text-tech-stack-title">Core Technologies</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {technologies.map((tech) => (
                  <div
                    key={tech.name}
                    className="flex flex-col items-center gap-3 p-4 rounded-lg bg-muted/50 hover-elevate active-elevate-2 transition-all cursor-default"
                    data-testid={`card-tech-${tech.name.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <tech.icon className="h-8 w-8 text-muted-foreground" />
                    <span className="text-sm font-medium">{tech.name}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
