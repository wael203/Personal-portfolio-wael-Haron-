import { ThemeToggle } from "./ThemeToggle";
import { Button } from "@/components/ui/button";
import { Code2 } from "lucide-react";
import { siteConfig } from "@/lib/config";

export function Header() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Code2 className="h-6 w-6 text-primary" />
          <span className="font-semibold text-lg" data-testid="text-logo">{siteConfig.name}</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-1 flex-wrap">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => scrollToSection("about")}
            data-testid="link-about"
          >
            About
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => scrollToSection("expertise")}
            data-testid="link-expertise"
          >
            Expertise
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => scrollToSection("skills")}
            data-testid="link-skills"
          >
            Skills
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => scrollToSection("contact")}
            data-testid="link-contact"
          >
            Contact
          </Button>
        </nav>

        <ThemeToggle />
      </div>
    </header>
  );
}
