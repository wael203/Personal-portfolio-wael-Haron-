import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const skillCategories = [
  {
    category: "Programming Languages",
    skills: [
      { name: "Python", level: 95 },
      { name: "JavaScript/TypeScript", level: 85 },
      { name: "SQL", level: 90 },
      { name: "Go", level: 70 },
    ],
  },
  {
    category: "ML & AI Frameworks",
    skills: [
      { name: "TensorFlow", level: 90 },
      { name: "PyTorch", level: 80 },
      { name: "Scikit-learn", level: 95 },
      { name: "Keras", level: 88 },
    ],
  },
  {
    category: "Cloud & DevOps",
    skills: [
      { name: "AWS", level: 92 },
      { name: "Google Cloud", level: 85 },
      { name: "Docker", level: 90 },
      { name: "Kubernetes", level: 78 },
    ],
  },
];

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 md:py-32 px-6 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4" data-testid="badge-section-skills">Skills</Badge>
          <h2 className="text-3xl md:text-4xl font-semibold mb-4" data-testid="text-skills-title">
            Technical Proficiency
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto" data-testid="text-skills-subtitle">
            A comprehensive skill set spanning the full stack of AI and cloud engineering.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category) => (
            <div key={category.category} className="space-y-6">
              <h3 className="text-lg font-semibold text-center" data-testid={`text-category-${category.category.toLowerCase().replace(/\s+/g, "-")}`}>
                {category.category}
              </h3>
              <div className="space-y-4">
                {category.skills.map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium">{skill.name}</span>
                      <span className="text-xs text-muted-foreground font-mono">{skill.level}%</span>
                    </div>
                    <Progress 
                      value={skill.level} 
                      className="h-2"
                      data-testid={`progress-skill-${skill.name.toLowerCase().replace(/[/\s]+/g, "-")}`}
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-lg font-semibold mb-6" data-testid="text-additional-skills">Additional Skills</h3>
          <div className="flex flex-wrap items-center justify-center gap-3">
            {[
              "REST APIs",
              "GraphQL",
              "Microservices",
              "System Design",
              "Agile/Scrum",
              "Git/GitHub",
              "CI/CD",
              "Linux",
              "Data Visualization",
              "Apache Spark",
            ].map((skill) => (
              <span
                key={skill}
                className="px-4 py-2 rounded-full bg-background border text-sm hover-elevate active-elevate-2 transition-all cursor-default"
                data-testid={`badge-additional-${skill.toLowerCase().replace(/[/\s]+/g, "-")}`}
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
