export const siteConfig = {
  name: "Wael Haron",
  title: "Software & AI Engineer",
  tagline: "Passionate about building smart systems that connect cloud, data, and machine learning.",
  
  hero: {
    highlight1: "cloud",
    highlight2: "data",
    highlight3: "machine learning",
  },
  
  social: {
    linkedin: "https://www.linkedin.com/in/wael-haron-92965a311",
    github: "https://github.com/wael203",
    instagram: "https://www.instagram.com/waelharon203",
    email: "waelharon203@gmail.com",
  },
  
  currentYear: new Date().getFullYear(),
};
