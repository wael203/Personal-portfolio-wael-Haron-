# Wael Haron - Professional Portfolio Website

## Overview
A modern, professional portfolio website for Wael Haron, a Software and AI Engineer. The site showcases expertise in cloud computing, machine learning, and AI automation with a clean, high-tech design.

## Project Structure
```
client/
├── src/
│   ├── components/         # Reusable UI components
│   │   ├── Header.tsx      # Fixed navigation header with theme toggle
│   │   ├── HeroSection.tsx # Full-height hero with name and tagline
│   │   ├── AboutSection.tsx # Bio and core technologies
│   │   ├── ExpertiseSection.tsx # Four expertise areas with cards
│   │   ├── SkillsSection.tsx # Technical skills with progress bars
│   │   ├── ContactSection.tsx # CTA and social links
│   │   ├── Footer.tsx      # Site footer
│   │   └── ThemeToggle.tsx # Dark/light mode toggle
│   ├── lib/
│   │   └── config.ts       # Site configuration (name, social links)
│   └── pages/
│       └── Home.tsx        # Main landing page
└── index.html              # Entry point with SEO meta tags

server/                     # Express backend (minimal for this static site)
```

## Configuration
All personal information and social links are centralized in `client/src/lib/config.ts`:
- LinkedIn URL
- GitHub URL  
- Email address

## Design System
- **Colors**: Professional blue color scheme (HSL 220 base)
- **Typography**: Inter/Space Grotesk for headings, Fira Code for tech elements
- **Spacing**: Consistent 4-unit scale
- **Dark Mode**: Full support with theme toggle

## Key Features
1. Smooth scroll navigation
2. Responsive design (mobile-first)
3. Dark/light mode toggle
4. Animated skill progress bars
5. Hover interactions on cards
6. SEO-optimized meta tags

## Development
- Run `npm run dev` to start the development server
- Frontend runs on port 5000
- Hot reload enabled via Vite
