# Design Guidelines: Wael Haron Portfolio

## Design Approach
**Reference-Based Design** drawing inspiration from modern tech portfolios (Linear, Vercel, GitHub) with high-tech, professional aesthetics. Focus on clean hierarchy, technical sophistication, and expertise demonstration.

## Typography System
- **Primary Font**: Inter or Space Grotesk (Google Fonts) - modern, technical feel
- **Hierarchy**:
  - Hero Name: text-5xl to text-7xl, font-bold
  - Tagline: text-xl to text-2xl, font-normal
  - Section Headers: text-3xl to text-4xl, font-semibold
  - Body Text: text-base to text-lg
  - Labels/Meta: text-sm, uppercase tracking-wide

## Layout System
**Tailwind Spacing**: Consistently use units of 4, 6, 8, 12, 16, 20, and 24 for vertical rhythm
- Container: max-w-6xl mx-auto
- Section padding: py-20 to py-32 (desktop), py-12 to py-16 (mobile)
- Component spacing: gap-8 to gap-12 for grids

## Page Structure

### Hero Section (Full Viewport Impact)
- Height: min-h-screen with flex centering
- Large background image: Abstract tech/code visualization or neural network pattern (subtle, professional)
- Content overlay with backdrop-blur on container
- Centered layout with name, tagline, and primary CTA
- Scroll indicator at bottom

### Expertise Section
- Two-column layout (lg:grid-cols-2)
- Left: Narrative about focus and current work
- Right: Technology stack displayed as interactive cards or badges
- Grid of 6-8 technology icons with labels (Python, TensorFlow, AWS, GCP, etc.)
- Each tech item: icon + name + subtle hover elevation

### Featured Skills/Capabilities Section
- Three-column grid (lg:grid-cols-3, md:grid-cols-2)
- Cards for: "Cloud Architecture", "Machine Learning", "AI Automation"
- Each card: icon header, title, 2-3 sentence description
- Subtle border, padding p-8, rounded corners

### Projects/Work Section (Optional but Recommended)
- Showcase 2-3 featured AI/ML projects
- Card layout with project thumbnail, title, tech stack tags, brief description
- "View on GitHub" links

### Contact/CTA Section
- Full-width section with centered content
- Headline: "Let's Build Something Together"
- Subtext about collaboration opportunities
- Social links as large icon buttons (LinkedIn, GitHub, Email)
- Alternative: Contact form with name, email, message fields

### Footer
- Minimal: Copyright, additional navigation, social links repeated
- Padding: py-8

## Component Specifications

**Buttons**:
- Primary: px-8 py-3, rounded-lg, font-medium
- On hero image: backdrop-blur-md with semi-transparent background
- Icon buttons (social): p-4, rounded-full, hover scale effect

**Cards**:
- Border: border, rounded-xl
- Padding: p-6 to p-8
- Shadow: subtle shadow-sm, hover:shadow-md transition

**Technology Badges**:
- Small pills: px-4 py-2, rounded-full, text-sm
- Display inline-flex with icons

**Links**:
- Underline on hover
- Social icons: Large (w-6 h-6 minimum), accessible hover states

## Images

**Hero Background Image**:
- Type: Abstract technology visualization, code patterns, or neural network graphic
- Treatment: Subtle opacity (0.15-0.3), grayscale or monochrome treatment
- Position: cover, center
- Must support text overlay readability

**Optional Project Thumbnails**:
- Aspect ratio: 16:9
- Screenshots of dashboards, ML models, or cloud architectures
- Position in project cards

## Animations
- Minimal, professional only:
  - Smooth scroll behavior
  - Fade-in on scroll for sections (once)
  - Hover scale (1.02-1.05) on cards and buttons
  - No complex animations or parallax

## Accessibility
- All interactive elements meet 44x44px touch targets
- Form inputs with clear labels and focus states
- Icon buttons include aria-labels
- High contrast text throughout
- Keyboard navigation support

## Icons
Use **Heroicons** (via CDN) for:
- Tech stack icons (can supplement with Font Awesome for specific brand logos)
- Social media icons
- UI elements (arrow indicators, external links)

## Special Considerations
- Code aesthetic: Consider subtle monospace font accents for tech keywords
- Glassmorphism effects on hero for modern tech feel
- Grid patterns or dot matrix backgrounds as subtle texture
- Professional photography of Wael (if available) in About/Contact section